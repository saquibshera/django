from django.shortcuts import render

# Create your views here.



def index(request):
    return render(request,'mytodoapp/index.html')


def about(request):
    return render(request,'mytodoapp/about.html')


def contact(request,id):
    return render(request,'mytodoapp/contact.html')