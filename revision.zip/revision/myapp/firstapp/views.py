from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect

from .models import information
from .forms import informationform
# Create your views here.


def home(request):
    if request.method=='POST':
        form=informationform(request.POST)
        if form.is_valid():
            form.save()
    form=informationform()
    names=information.objects.all()
    context={'names':names,'forms':form}
    return render(request,'firstapp/home.html',context)

def contact(request):
    return HttpResponse("weclome")

def delete(request,id):
    information.objects.get(pk=id).delete()
    return redirect('home')
