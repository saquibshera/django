from django import forms
from .models import information

class informationform(forms.ModelForm):
    class Meta:
        model=information
        fields='__all__'