from django.contrib import admin
from .models import information
# Register your models here.


admin.site.register(information)
